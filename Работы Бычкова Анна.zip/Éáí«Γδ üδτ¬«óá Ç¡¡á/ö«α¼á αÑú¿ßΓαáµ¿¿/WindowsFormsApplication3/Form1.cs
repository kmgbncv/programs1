﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        Panel p;

        List<Runner> runners;

        int total_distance = 0;

        public Form1()
        {
            InitializeComponent();
            runners = new List<Runner>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (runners.Count == 0)
            {
                MessageBox.Show("Для создания списка нужно от 1 участника!","Ошибка");
                return;
            }
           

            foreach (var item in runners)
            {
                item.Distance = 0;
            }
            int number;

            bool success = Int32.TryParse(txt_dist.Text, out number);
            if(success==false)
            {
                MessageBox.Show("Введено неверное значение дистанции!", "Ошибка");
                return;
            }
            total_distance = Convert.ToInt32(txt_dist.Text);

            if (total_distance==0)
            {
                MessageBox.Show("Для начала соревнования введите дистанцию!", "Ошибка");
                return;
            }
            this.Controls.RemoveByKey("Panel1");

            int Top = 40;
            int margin = 10;

            p = new Panel();
            p.Location = new Point(10, Top);
            p.Size = new Size(this.ClientSize.Width - 20, this.ClientSize.Height - 20);
            p.Name = "Panel1";
            p.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right | AnchorStyles.Bottom;
            p.BackColor = Color.FromArgb(255, 0, 255, 255);
            p.AutoScroll = true;
            p.Tag = "panel";
            this.Controls.Add(p);



            int TopPreText = 0;
            var r = new Random();
            for (int i = 0; i < runners.Count; i++)
            {
                Label label = new Label();
                label.Size = new Size(90,30);
                label.Location = new Point(10, Top);
                label.Name = "pbar" + i;
                label.Parent = p;
                label.Text ="Игрок № "+runners[i].RegN;
                label.Font = new Font("Times New Roman", 10, FontStyle.Regular);
                

                ProgressBar pbar = new ProgressBar();
                pbar.Size = new Size(p.Width - 100, 25);
                pbar.Location = new Point(100, Top);
                pbar.Name = "pbar" + i;
                pbar.Parent = p;
                pbar.Text = "";
                pbar.Font = new Font("Times New Roman", 10, FontStyle.Regular);
                pbar.Minimum = 0;
                pbar.Maximum = total_distance;

                

                pbar.Value = 0;

                pbar.Tag = runners[i].RegN;

                TopPreText = pbar.Top;

                p.Controls.Add(pbar);

                int sizeFont = (int)pbar.Font.GetHeight();

                Top = TopPreText + sizeFont + margin + 6;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (p==null)
            {
                timer1.Enabled = false;
                MessageBox.Show("Для начала создайте список!", "Ошибка");
                return;
            }
            var r = new Random();
            int g = 0;
            int[,] arr = new int [2,runners.Count];
            
                foreach (var runner in runners)
                {
                    arr[0, g] = runner.RegN;
                    arr[1, g] = runner.Distance;
                    g++;
                }
            
            int y = arr.Length/2;
            for (int i = 0; i < y; i++)
            {
                runners[i].IsRun = true;
                foreach (Control item in p.Controls)
                {
                    if (typeof(ProgressBar)!=item.GetType())
                    {
                        continue;
                    }
                    ProgressBar j= (ProgressBar)item;
                    int tg = Convert.ToInt32(j.Tag);
                    if (arr[0,i]==tg)
                    {
                        try
                        {
                            int value = (int)(r.NextDouble() * 100.0);
                            int dis2 = arr[1, i] + value;
                            runners[i].Distance = dis2;
                            j.Value = dis2;
                        }
                        catch
                        {
                            timer1.Enabled = false;
                            runners[i].IsRun = false;
                            j.Value = total_distance;
                            
                            MessageBox.Show("Игрок под номером " + j.Tag + " выиграл \nФИО: " +runners[i].FIO+"\nПол: "+runners[i].Gender+"\nДата рождения: "+runners[i].DateBirth, "Победа");
                            return;
                        }
                    }
                }
                
            }
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (FormRegistration form = new FormRegistration())
            {

                Runner c = new Runner();

                form.Registration(c);
                if (c.RegN!=-1&&c.FIO != "" && c.Gender != "" && c.DateBirth != "")
                {
                    runners.Add(c);
                }
                else
                {
                    MessageBox.Show("Регистрация была завершена досрочно или участник был неверно зарегистрирован.");
                }
                

            }
        }
    }
}
