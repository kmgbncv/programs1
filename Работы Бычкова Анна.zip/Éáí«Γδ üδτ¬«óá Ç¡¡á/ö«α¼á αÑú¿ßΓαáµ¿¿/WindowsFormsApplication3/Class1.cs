﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication3
{
    public class Runner
    {
        public string FIO { get; set; }
        public string Gender { get; set; }
        public string DateBirth { get; set; }
        public int Distance { get; set; }
        public bool IsRun { get; set; }
        public int RegN { get; set; }
    }
}
