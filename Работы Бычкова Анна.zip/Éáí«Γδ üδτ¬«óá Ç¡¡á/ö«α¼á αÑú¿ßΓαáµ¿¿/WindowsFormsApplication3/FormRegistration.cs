﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class FormRegistration : Form
    {
        public FormRegistration()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        public void Registration(Runner c)
        {
            this.ShowDialog();

            c.FIO = txt_FIO.Text;
            c.Gender = txt_Gender.Text;
            c.DateBirth=txt_datebirth.Text;
           
            try
            {
                c.RegN = Convert.ToInt32(txt_regn.Text);
            }
            catch
            {
                
                c.RegN = -1;
            }
        }

        private void FormRegistration_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
