﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {

        Graphics g;
        PointF p;

        float offcetX = 2f;
        float offcetY = 2f;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            p = new Point(10, 10);
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            Size sizeCircle = new Size(100, 100);
            SolidBrush redBrush = new SolidBrush(Color.Red);

            g.Clear(this.BackColor);

            g.FillEllipse(redBrush, p.X, p.Y, sizeCircle.Width, sizeCircle.Height);
            g.DrawEllipse(new Pen(Color.Black, 4), p.X, p.Y, sizeCircle.Width, sizeCircle.Height);

            p.X += offcetX;
            p.Y += offcetY;
            if (p.Y + sizeCircle.Width == this.ClientSize.Height)
            {
                offcetY = -2F;
            }
            if (p.Y  == 0)
            {
                offcetY = 2F;
            }
            if (p.X + sizeCircle.Width == this.ClientSize.Width)
            {
                offcetX = -2F;
            }
            if (p.X  == 0)
            {
                offcetX = 2F;
            }


            //this.ClientSize.Height // Высота формы

            //this.ClientSize.Width // Длина формы
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
        }
    }
}
